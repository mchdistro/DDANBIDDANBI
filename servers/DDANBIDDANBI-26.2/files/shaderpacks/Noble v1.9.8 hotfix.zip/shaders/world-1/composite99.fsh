#version 430 compatibility

#define STAGE_FRAGMENT

#include "/programs/post/color_grading.glsl"
