#version 430 compatibility

#define STAGE_VERTEX

#define BLOOM_DOWNSAMPLE_PASS
#define BLOOM_DOWNSAMPLE_PASS_INDEX 3

#include "/programs/post/bloom/tile_write.glsl"
