#version 430 compatibility

#define STAGE_VERTEX
#define WORLD_END

#include "/programs/composite/specular_write.glsl"
