/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

const float invShadowMapResolution = 1.0 / shadowMapResolution;

float jitter0 = interleavedGradientNoise(SCREEN_COORDS);
float jitter1 = interleavedGradientNoise(SCREEN_COORDS.yx * 0.9 + vec2(viewSize * 0.3));

#if CONTACT_SHADOWS == 1

    float traceContactShadows(
        sampler2D depthTexture,
        mat4 projection,
        mat4 projectionInverse,
        vec3 viewPosition,
        float scale,
        inout float subsurfaceDepth
    ) {
        // DDA setup (McGuire & Mara, 2014)
        vec3 rayPosition;
        vec3 rayDirection;
        rayPosition   = viewToScreen(viewPosition, projection, true);
        rayDirection  = viewPosition + abs(viewPosition.z) * normalize(shadowLightVector);
        rayDirection  = viewToScreen(rayDirection, projection, true) - rayPosition;
        rayDirection *= minOf((step(0.0, rayDirection) - rayPosition) / rayDirection);

        vec2 resolution = viewSize * scale;

        rayPosition.xy  *= resolution;
        rayDirection.xy *= resolution;

        vec3 startPosition = rayPosition;

        // Normalise the DDA ray step to walk a fixed amount of pixels per step
        rayDirection /= maxOf(abs(rayDirection.xy));
        // Scale it to the stride (in pixels)
        rayDirection *= float(CONTACT_SHADOWS_STRIDE);

        float initialDepth = rayPosition.z;

        // Jitter the first step
        rayPosition += rayDirection * jitter0;

        bool intersected = false;

        for (int i = 0; i < CONTACT_SHADOWS_STEPS; i++) {

            float depth = texelFetch(depthTexture, ivec2(rayPosition.xy), 0).r;

            float linearDepth    = linearizeDepth(depth);
            float linearRayDepth = linearizeDepth(rayPosition.z);

            float relativeGap = abs(linearRayDepth - linearDepth) / linearRayDepth;

            // Check if the ray and the fragment are near enough for contact shadows
            if (relativeGap < 0.02) {
                float maxZ  = rayPosition.z;
                float minZ  = rayPosition.z - float(CONTACT_SHADOWS_STRIDE) / linearDepth;

                // Intersection check, avoid player hand fragments
                if(maxZ >= depth && minZ <= depth && depth >= handDepth) {
                    intersected = true;
                    break;
                } 
            }

            rayPosition += rayDirection;
        }

        if (intersected) {
            subsurfaceDepth = distance(startPosition, rayPosition);
        }

        return float(!intersected);
    }

#endif

float shadowVisibility(sampler2D shadowTex, vec3 samplePosition) {
    return step(samplePosition.z, texelFetch(shadowTex, ivec2(samplePosition.xy * shadowMapResolution), 0).r);
}

vec3 getShadowColor(vec3 samplePosition) {
    if (!insideScreenBounds(samplePosition, 1.0)) return vec3(1.0);

    float shadowDepth0 = shadowVisibility(shadowtex0, samplePosition);
    float shadowDepth1 = shadowVisibility(shadowtex1, samplePosition);

    vec4 shadowColor = texelFetch(shadowcolor0, ivec2(samplePosition.xy * shadowMapResolution), 0);

    shadowColor.rgb = SRGB_TO_WORKING_SPACE(shadowColor.rgb);

    return mix(vec3(shadowDepth0), shadowColor.rgb * (1.0 - shadowColor.a), saturate(shadowDepth1 - shadowDepth0));
}

uniform sampler2D shadowcolor1;

float getShadowCaustics(vec3 samplePosition) {
    if (!insideScreenBounds(samplePosition, 1.0)) return 0.0;

    float shadowDepth0 = shadowVisibility(shadowtex0, samplePosition);
    float shadowDepth1 = shadowVisibility(shadowtex1, samplePosition);

    return texelFetch(shadowcolor1, ivec2(samplePosition.xy * shadowMapResolution), 0).r * saturate(shadowDepth1 - shadowDepth0);
}

#if SHADOWS > 0

    float findBlockerDepth(vec2 shadowCoords, float shadowDepth, out float subsurfaceDepth) {
        float blockerDepthSum    = 0.0;
        float subsurfaceDepthSum = 0.0;

        float weightSum = 0.0;

        for (int i = 0; i < BLOCKER_SEARCH_SAMPLES; i++) {
            
            vec2 offset       = BLOCKER_SEARCH_RADIUS * sampleDisk(i, BLOCKER_SEARCH_SAMPLES, jitter0, jitter1) * invShadowMapResolution;
            vec2 sampleCoords = shadowClipToShadowScreen(shadowCoords + offset);
            
            if (!insideScreenBounds(sampleCoords, 1.0)) return -1.0;

            float depth  = texelFetch(shadowtex0, ivec2(sampleCoords * shadowMapResolution), 0).r;
            float weight = step(depth, shadowDepth);

            blockerDepthSum += depth * weight;
            weightSum       += weight;

            subsurfaceDepthSum += max0(shadowDepth - depth);
        }
        
        // Linearized distance travelled through the block
        subsurfaceDepth = max0(subsurfaceDepthSum) * RCP_BLOCKER_SEARCH_SAMPLES * -shadowProjectionInverse[2].z * RCP_SHADOWS_DEPTH_STRETCH;

        return weightSum == 0.0 ? -1.0 : blockerDepthSum / weightSum;
    }

    vec3 PCF(vec3 shadowPosition, float penumbraSize, vec3 selfIntersectionBias) {
        if (penumbraSize < EPS) {
            return getShadowColor(shadowClipToShadowScreen(shadowPosition) - selfIntersectionBias);
        }

        vec3 shadows = vec3(0.0);
        vec2 offset  = vec2(0.0);

        for (int i = 0; i < SHADOW_SAMPLES; i++) {
             
            #if SHADOWS != 3
                offset = sampleDisk(i, SHADOW_SAMPLES, jitter0, jitter1) * penumbraSize * invShadowMapResolution;
            #endif

            vec3 samplePosition = shadowClipToShadowScreen(shadowPosition + vec3(offset, 0.0));

            shadows += getShadowColor(samplePosition - selfIntersectionBias);
        }

        return shadows * rcp(SHADOW_SAMPLES);
    }

    vec4 calculateShadowMapping(vec3 scenePosition, vec3 geometricNormal, float depth) {
        vec3 shadowPositionClip = worldToShadowClip(scenePosition);

        float NdotL = dot(geometricNormal, shadowLightVectorWorld);

        shadowPositionClip += getShadowBias(shadowPositionClip, geometricNormal);

        float penumbraSize = NORMAL_SHADOW_PENUMBRA;

        vec3 selfIntersectionBias = vec3(0.0);

        if (depth < handDepth) {
            selfIntersectionBias = vec3(0.0, 0.0, 1e-3);
        }

        vec3 shadowPositionScreen = shadowClipToShadowScreen(shadowPositionClip);

        if (!insideScreenBounds(shadowPositionScreen, 1.0)) {
            return vec4(1.0, 1.0, 1.0, 0.0);
        }

        float subsurfaceDepth = 0.0;
        float avgBlockerDepth = findBlockerDepth(shadowPositionClip.xy, shadowPositionScreen.z, subsurfaceDepth);

        if (NdotL < 0.0) {
            return vec4(0.0, 0.0, 0.0, subsurfaceDepth);
        }

        #if SHADOWS == 1
            penumbraSize = max(MIN_SHADOW_PENUMBRA, LIGHT_SIZE * max0(shadowPositionScreen.z - avgBlockerDepth) / avgBlockerDepth);
        #endif

        return vec4(
            PCF(shadowPositionClip, penumbraSize, selfIntersectionBias) + getShadowCaustics(shadowPositionScreen),
            subsurfaceDepth
        );
    }

#endif
