/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

const float exposureBias = 1.0;

const float minExposure = exposureBias * 2.0e-5;
const float maxExposure = exposureBias * 1.5e-1;

const float calibration       = 12.5;  // Light meter calibration
const float sensorSensitivity = 100.0; // Sensor sensitivity

float computeEV100fromLuminance(float luminance) {
    return log2(luminance * sensorSensitivity * exposureBias / calibration);
}

float computeExposureFromEV100(float ev100) {
    return exp2(-ev100);
}

float computeExposure(float averageLuminance) {
    #if EXPOSURE == 0

        float ev100    = log2((F_STOPS * F_STOPS) / (1.0 / SHUTTER_SPEED) * sensorSensitivity / ISO);
        float exposure = computeExposureFromEV100(ev100);

    #else

        float ev100	   = computeEV100fromLuminance(averageLuminance);
        float exposure = computeExposureFromEV100(ev100);

    #endif

    return clamp(exposure, minExposure, maxExposure);
}

float fetchCurrentExposure() {
    return computeExposure(texelFetch(HISTORY_BUFFER, ivec2(0, 0), 0).a);
}

#if defined IS_IRIS

    layout (std430, binding = 0) restrict buffer currentExposureBuffer {
        float currentExposure;
    };

    #define CURRENT_EXPOSURE() \
        currentExposure

#else

    #define CURRENT_EXPOSURE() \
        fetchCurrentExposure()

#endif
