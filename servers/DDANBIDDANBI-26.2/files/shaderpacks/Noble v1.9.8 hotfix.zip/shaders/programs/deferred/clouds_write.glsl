/********************************************************************************/
/*                                                                              */
/*    Noble Shaders                                                             */
/*    Copyright (C) 2026  Belmu                                                 */
/*                                                                              */
/*    This program is free software: you can redistribute it and/or modify      */
/*    it under the terms of the GNU General Public License as published by      */
/*    the Free Software Foundation, either version 3 of the License, or         */
/*    (at your option) any later version.                                       */
/*                                                                              */
/*    This program is distributed in the hope that it will be useful,           */
/*    but WITHOUT ANY WARRANTY; without even the implied warranty of            */
/*    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the             */
/*    GNU General Public License for more details.                              */
/*                                                                              */
/*    You should have received a copy of the GNU General Public License         */
/*    along with this program.  If not, see <https://www.gnu.org/licenses/>.    */
/*                                                                              */
/********************************************************************************/

#include "/settings.glsl"

#if CLOUDS_LAYER0_ENABLED == 0 && CLOUDS_LAYER1_ENABLED == 0 || !defined WORLD_OVERWORLD

    #include "/programs/discard.glsl"

#else

    #include "/include/taau_scale.glsl"

    #if defined STAGE_VERTEX
    
        #include "/programs/vertex_simple.glsl"

    #elif defined STAGE_FRAGMENT

        #if CLOUDMAP == 1

            /* RENDERTARGETS: 7,14 */

            layout (location = 0) out vec4 cloudsOut;
            layout (location = 1) out vec3 cloudmapOut;

        #else

            /* RENDERTARGETS: 7 */

            layout (location = 0) out vec4 cloudsOut;

        #endif

        in vec2 textureCoords;

        #include "/include/common.glsl"

        #include "/include/utility/rng.glsl"
        #include "/include/utility/phase.glsl"
        
        #include "/include/atmospherics/constants.glsl"
        #include "/include/atmospherics/clouds.glsl"

        void main() {

            // Clouds setup

            vec2 vertexCoords = textureCoords * RENDER_SCALE;

            cloudsOut = vec4(0.0, 0.0, 1.0, cloudsFallbackDistance);

            bool  modFragment = false;
            float depth       = texture(depthtex0, vertexCoords).r;

            if (depth < handDepth) { return; }

            mat4 projectionInverse = gbufferProjectionInverse;

            #if defined CHUNK_LOADER_MOD_ENABLED

                if (depth >= 1.0) {
                    modFragment       = true;
                    projectionInverse = modProjectionInverse;
                }
                
            #endif

            // Cloudmap rendering

            #if CLOUDMAP == 1

                if (insideScreenBounds(textureCoords, CLOUDMAP_SCALE)) {

                    vec3 cloudsCoords   = normalize(unprojectSphere(textureCoords * rcp(CLOUDMAP_SCALE)));
                    vec4 cloudmapLayer0 = estimateCloudsScattering(cloudLayer0, cloudsCoords, true, false);
                    vec4 cloudmapLayer1 = estimateCloudsScattering(cloudLayer1, cloudsCoords, false, false);

                    cloudmapOut.rg  = cloudmapLayer0.rg + cloudmapLayer1.rg * cloudmapLayer0.b;
                    cloudmapOut.b   = cloudmapLayer0.b  * cloudmapLayer1.b;
                    cloudmapOut.rgb = max0(cloudmapOut.rgb);

                }

            #endif

            if (modFragment) {
                if (find2x2MaximumDepth(modDepthTex0, vertexCoords) < 1.0) { return; }
            } else {
                if (find2x2MaximumDepth(depthtex0, vertexCoords) < 1.0) { return; }
            }

            // Cloud layers tracing

            vec3 viewPosition       = screenToView(vec3(textureCoords, 1.0), projectionInverse, false);
            vec3 cloudsRayDirection = mat3(gbufferModelViewInverse) * normalize(viewPosition);

            vec4 layer0 = vec4(0.0, 0.0, 1.0, cloudsFallbackDistance);
            vec4 layer1 = vec4(0.0, 0.0, 1.0, cloudsFallbackDistance);

            #if CLOUDS_LAYER0_ENABLED == 1
                layer0 = estimateCloudsScattering(cloudLayer0, cloudsRayDirection, true, true);
            #endif

            #if CLOUDS_LAYER1_ENABLED == 1
                layer1 = estimateCloudsScattering(cloudLayer1, cloudsRayDirection, false, true);
            #endif

            // Distance to clouds
            cloudsOut.a = min(layer0.a, layer1.a);

            // Cloud layers blending

            float s = step(layer0.a, layer1.a);

            vec2  C_front = mix(layer1.rg, layer0.rg, s);
            float T_front = mix(layer1.b,  layer0.b,  s);

            vec2  C_back  = mix(layer0.rg, layer1.rg, s);
            float T_back  = mix(layer0.b,  layer1.b,  s);

            cloudsOut.rg = C_front + T_front * C_back;
            cloudsOut.b  = T_front * T_back;

            // Reprojection

            vec2 prevCoords = reproject(viewPosition, cloudsOut.a, CLOUDS_WIND_SPEED * frameTime * windDirection).xy;

            if (insideScreenBounds(prevCoords, 1.0)) {

                vec4 history = texture(CLOUDS_BUFFER, prevCoords);

                float distanceFalloff = quinticStep(0.0, 1.0, sqrt(max0(exp(-5e-5 * cloudsOut.a))));

                vec2 pixelCenterDist = 1.0 - abs(fract(prevCoords * viewSize) * 2.0 - 1.0);

                const float centerWeightStrength = CLOUDS_CENTER_WEIGHT_STRENGTH * CLOUDS_SCALE * 0.01;

                float centerWeight = sqrt(pixelCenterDist.x * pixelCenterDist.y) * centerWeightStrength + (1.0 - centerWeightStrength);
                      centerWeight = mix(0.9, centerWeight, distanceFalloff);
                
                float velocityWeight = saturate(exp(-CLOUDS_VELOCITY_WEIGHT_STRENGTH * length(cameraPosition - previousCameraPosition)));

                const float maxCloudsTemporalWeight = 0.998;
                const float maxCloudsDistanceDelta  = 45000.0;

                float weight  = clamp(centerWeight * velocityWeight, 0.0, maxCloudsTemporalWeight);
                      weight *= float(abs(cloudsOut.a - history.a) < maxCloudsDistanceDelta);

                cloudsOut.rgb = max0(mix(cloudsOut.rgb, history.rgb, weight));

            }
        }
        
    #endif

#endif
