#version 430 compatibility

#define PROGRAM_LIGHTNING
#define STAGE_VERTEX
#define WORLD_OVERWORLD

#include "/programs/gbuffers/forward.glsl"
