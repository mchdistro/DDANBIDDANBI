#version 430 compatibility

#define STAGE_VERTEX
#define WORLD_OVERWORLD

#include "/programs/deferred/shadows_and_skylight.glsl"
